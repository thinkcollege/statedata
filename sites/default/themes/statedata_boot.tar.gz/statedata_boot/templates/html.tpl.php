<!DOCTYPE html>
<html lang="<?php print $language->language; ?>" dir="<?php print $language->dir; ?>"<?php print $rdf_namespaces;?>>
<head profile="<?php print $grddl_profile; ?>">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <?php print $head; ?>
  <title><?php print $head_title; ?></title>
  <?php print $styles; ?>
     <link href="http://getbootstrap.com/examples/jumbotron/jumbotron.css" rel="stylesheet">
   <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
   <link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:700' rel='stylesheet' type='text/css'>

  <!-- HTML5 element support for IE6-8 -->
  <!--[if lt IE 9]>
    <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->


  <?php print $scripts; ?>
 <script type="text/javascript">

 /* function onPageshow(){ var form = jQuery('.headFront #d3-statedata-dependent-dropdown');
    // let the browser natively reset defaults
    form[0].reset();
   jQuery(window).bind("pageshow", function() {
    var form = jQuery('.headFront #d3-statedata-dependent-dropdown');
    // let the browser natively reset defaults
    form[0].reset();
    form.find(':input').not(':button,:submit,:reset').trigger('change');
});} */
function clearForms()
{
    jQuery.noConflict();
  var i;
  for (i = 0; (i < document.forms.length); i++) {
    document.forms[i].reset();



  }
 stateform = jQuery('.headFront #d3-statedata-dependent-dropdown');
 stateform.find(':input').not(':button,:submit,:reset').trigger('change');



}

</script>
</head>
<body onunload="clearForms()" onload="clearForms()" onunload="clearForms()" class="<?php print $classes; ?>" <?php print $attributes;?>><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-962830-8', 'auto');
  ga('send', 'pageview');

</script>
  <div id="skip-link">
    <a href="#main-content" class="element-invisible element-focusable"><?php print t('Skip to main content'); ?></a>
  </div>
  <?php print $page_top; ?>
  <?php print $page; ?>
  <?php print $page_bottom; ?>
</body>
</html>
